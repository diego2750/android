package com.multiplesactivitys;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MayorEdad extends AppCompatActivity {

    TextView txtMayor;
    TextView txtNumUno;
    TextView txtNumDos;
    EditText txtResultado;

    int num1 = (int) (Math.random()*101);
    int num2 = (int) (Math.random()*101);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mayor_edad);

        txtMayor = findViewById(R.id.txtMayor);
        txtNumUno = findViewById(R.id.txtNumUno);
        txtNumDos = findViewById(R.id.txtNumDos);
        txtResultado = findViewById(R.id.txtResultado);

        txtNumUno.setText(String.valueOf(num1));
        txtNumDos.setText(String.valueOf(num2));
    }

    private static boolean isNumeric(String cadena){
        try {
            Integer.parseInt(cadena);
            return true;
        } catch (NumberFormatException nfe){
            return false;
        }
    }

    private void calculo(){
        int resultado = Integer.parseInt(String.valueOf(txtResultado.getText()));
        int datos = num1 * num2;

        if(isNumeric(txtResultado.getText().toString()) == false){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Dato invalido");
            builder.show();
        }
        else if(resultado == datos){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Bien hecho eres todo un adulto");
            builder.show();
        }
        else{
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Se supone que eres adulto, no te equivoques");
            builder.show();
        }
    }

    public void calcular(View view) {
        switch (view.getId()) {
            case R.id.btnCalcularar:
                this.calculo();
                break;
        }
    }
}