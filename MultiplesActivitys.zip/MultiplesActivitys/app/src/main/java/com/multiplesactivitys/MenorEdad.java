package com.multiplesactivitys;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MenorEdad extends AppCompatActivity {

    TextView txtMenor;
    TextView txtNumUno;
    TextView txtNumDos;
    EditText txtResultado;

    int num1 = (int) (Math.random()*101);
    int num2 = (int) (Math.random()*101);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menor_edad);

        txtMenor = findViewById(R.id.txtMenor);
        txtNumUno = findViewById(R.id.txtNumUno);
        txtNumDos = findViewById(R.id.txtNumDos);
        txtResultado = findViewById(R.id.txtResultado);

        txtNumUno.setText(String.valueOf(num1));
        txtNumDos.setText(String.valueOf(num2));

    }

    private static boolean isNumeric(String cadena){
        try {
            Integer.parseInt(cadena);
            return true;
        } catch (NumberFormatException nfe){
            return false;
        }
    }

    private void calculo(){
        int resultado = Integer.parseInt(String.valueOf(txtResultado.getText()));
        int datos = num1 + num2;

        if(!isNumeric(txtResultado.getText().toString())){
            Toast.makeText(this, "Esto no es un numero entero", Toast.LENGTH_SHORT).show();
        }
        else if(resultado == datos){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Bien hecho al parecer no eres tan joven");
            builder.show();
        }
        else{
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Vamos es una suma facil tu puedes");
            builder.show();
        }
    }

    public void calcular(View view) {
        switch (view.getId()) {
            case R.id.btnCalcularar:
                this.calculo();
                break;
        }
    }
}