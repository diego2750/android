package com.multiplesactivitys;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{
    EditText campo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        campo = findViewById(R.id.txtEdad);
    }

    private static boolean isNumeric(String cadena){
        try {
            Integer.parseInt(cadena);
            return true;
        } catch (NumberFormatException nfe){
            return false;
        }
    }

    private void redireccionar(){
        int campoEdad;
        campoEdad = Integer.parseInt (String.valueOf(campo.getText()));

       if(isNumeric(campo.getText().toString()) == false || campo.getText().toString().isEmpty()){
           AlertDialog.Builder builder = new AlertDialog.Builder(this);
           builder.setMessage("El dato no es valido");
       }
       else if(campoEdad <= 24) {
            Intent intent_menor = new Intent(this, MenorEdad.class);
            startActivity(intent_menor);
        }
       else if(campoEdad >= 25) {
            Intent intent_mayor = new Intent(this, MayorEdad.class);
            startActivity(intent_mayor);
        }
    }

    public void cerrar() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Desea cerrar la actividad").setPositiveButton("Si", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        }).setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    public void pulsar(View view) {
        switch (view.getId()) {
            case R.id.btnMostrar:
                this.redireccionar();
                break;

            case R.id.cerrarApp:
                this.cerrar();
                break;
        }
    }
}