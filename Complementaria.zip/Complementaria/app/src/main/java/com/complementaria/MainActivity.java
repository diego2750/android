package com.complementaria;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText campo1, campo2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        campo1 = findViewById(R.id.num1);
        campo2 = findViewById(R.id.num2);
    }

    private void operar(View view){
        String campoN1, campoN2;
        campoN1 = campo1.getText().toString();
        campoN2 = campo2.getText().toString();
        if(view.getId() == R.id.btnRestar){
            int d1 = Integer.parseInt(campoN1);
            int d2 = Integer.parseInt(campoN2);
            int resta = d1 - d2;

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("El resultado es "+resta);
            builder.show();
        }
        else if(view.getId() == R.id.btnMultiplicar){
            int d1 = Integer.parseInt(campoN1);
            int d2 = Integer.parseInt(campoN2);
            int mul = d1 * d2;

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("El resultado es "+mul);
            builder.show();
        }
        else if(view.getId() == R.id.btnDividir){
            int d1 = Integer.parseInt(campoN1);
            int d2 = Integer.parseInt(campoN2);
            int div = d1 / d2;

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("El resultado es "+div);
            builder.show();
        }
        else if(campoN1.isEmpty() == true || campoN2.isEmpty() == true){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Faltan datos");
            builder.show();
        }
    }

    public void pulsar(View view) {
        this.operar(view);
    }
}