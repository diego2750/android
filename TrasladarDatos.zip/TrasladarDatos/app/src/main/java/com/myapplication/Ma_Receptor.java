package com.myapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.icu.util.Calendar;
import android.icu.util.GregorianCalendar;
import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;

public class Ma_Receptor extends AppCompatActivity {

    private TextView txtAñoBisiesto, txtMeses, txtSemanas, txtDias;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ma_receptor);

        txtAñoBisiesto = findViewById(R.id.txtAñoBisiesto);
        txtMeses = findViewById(R.id.txtMeses);
        txtSemanas = findViewById(R.id.txtSemanas);
        txtDias = findViewById(R.id.txtDias);

        this.obtener();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void obtener(){

        //Se agrega el objeto Bundle, este permite obtener los datos
        //trasladados por el intent con su metodo putExtra y poder manipularlos en
        //la actividad que fue llamado
        Bundle bundle = getIntent().getExtras();
        if(bundle != null){
            String año = bundle.getString("año");

            GregorianCalendar calendar = new GregorianCalendar();

            if (calendar.isLeapYear(Integer.parseInt(año))) {
                txtAñoBisiesto.setText(año+" es año bisiesto");
                txtMeses.setText("12.03 meses");
                txtSemanas.setText("52.28 semanas");
                txtDias.setText("366 días ");
            }
            else {
                txtAñoBisiesto.setText(año+" es un año natural");
                txtMeses.setText("12 meses");
                txtSemanas.setText("52.14 semanas");
                txtDias.setText("365 días ");
            }
        }
        else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Datos no encontrados");
            builder.show();
        }

    }
}