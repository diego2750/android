package com.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText campoA;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        campoA = findViewById(R.id.txtAño);
    }

    private void dato() {
        String año = campoA.getText().toString();

        if(!año.isEmpty()){
            Intent intent = new Intent(this, Ma_Receptor.class);
            intent.putExtra("año", año);
            startActivity(intent);

        }
        else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("No ha ingresdo ningin año");
            builder.show();
        }

    }


    public void onClick(View view) {
        this.dato();
    }
}