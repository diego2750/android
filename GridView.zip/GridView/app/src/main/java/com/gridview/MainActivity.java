package com.gridview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    GridView gridView;
    ArrayList<String> colorN = new ArrayList<>();
    ArrayList<Integer> color = new ArrayList<>();
    ArrayList<String> hexa = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = findViewById(R.id.gridId);

        colorN.add("Yellow Green");
        colorN.add("Pastel Green");
        colorN.add("Keppel");
        colorN.add("Niagara");
        colorN.add("Bermuda");
        colorN.add("Fountain Blue");
        colorN.add("Ming");
        colorN.add("Tarawera");
        colorN.add("Danube");
        colorN.add("Indigo");
        colorN.add("Jacksons Purple");
        colorN.add("Madison");
        colorN.add("Manhattan");
        colorN.add("Cinnabar");
        colorN.add("Scarlet");
        colorN.add("Cardinal");
        colorN.add("Cherokee");
        colorN.add("Saffron");
        colorN.add("Neon Carrot");
        colorN.add("Fire Bush");

        color.add(Color.parseColor("#b8e994"));
        color.add(Color.parseColor("#78e08f"));
        color.add(Color.parseColor("#38ada9"));
        color.add(Color.parseColor("#079992"));
        color.add(Color.parseColor("#82ccdd"));
        color.add(Color.parseColor("#60a3bc"));
        color.add(Color.parseColor("#3c6382"));
        color.add(Color.parseColor("#0a3d62"));
        color.add(Color.parseColor("#6a89cc"));
        color.add(Color.parseColor("#4a69bd"));
        color.add(Color.parseColor("#1e3799"));
        color.add(Color.parseColor("#0c2461"));
        color.add(Color.parseColor("#f8c291"));
        color.add(Color.parseColor("#e55039"));
        color.add(Color.parseColor("#eb2f06"));
        color.add(Color.parseColor("#b71540"));
        color.add(Color.parseColor("#fad390"));
        color.add(Color.parseColor("#f6b93b"));
        color.add(Color.parseColor("#fa983a"));
        color.add(Color.parseColor("#e58e26"));

        hexa.add("#b8e994");
        hexa.add("#78e08f");
        hexa.add("#38ada9");
        hexa.add("#079992");
        hexa.add("#82ccdd");
        hexa.add("#60a3bc");
        hexa.add("#3c6382");
        hexa.add("#0a3d62");
        hexa.add("#6a89cc");
        hexa.add("#4a69bd");
        hexa.add("#1e3799");
        hexa.add("#0c2461");
        hexa.add("#f8c291");
        hexa.add("#e55039");
        hexa.add("#eb2f06");
        hexa.add("#b71540");
        hexa.add("#fad390");
        hexa.add("#f6b93b");
        hexa.add("#fa983a");
        hexa.add("#e58e26");

        AdaptadorGrid adaptadorGrid = new AdaptadorGrid(this,R.layout.grid_personalizado, colorN, color);
        gridView.setAdapter(adaptadorGrid);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), MA_color.class);
                intent.putExtra("color", color.get(i));
                intent.putExtra("hexa", hexa.get(i));
                startActivity(intent);
            }
        });
    }
}