package com.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;


public class MAPais extends AppCompatActivity {

    private ImageView img;
    private TextView tex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapais);
        img = findViewById(R.id.imgPais);
        tex = findViewById(R.id.txtTexto);

        this.recibirImagen();
    }

    private void recibirImagen(){
        Bundle bundle = getIntent().getExtras();
        int imagen = bundle.getInt("imagen");
        long texto = (long) (double) bundle.getLong("texto");
        img.setImageResource(imagen);
        tex.setText(String.valueOf(texto));
    }
}