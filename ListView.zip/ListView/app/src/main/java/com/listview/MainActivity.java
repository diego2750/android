package com.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView lista;
    ArrayList<String> pais = new ArrayList<>();
    ArrayList<Integer> img = new ArrayList<>();
    ArrayList<Long> info = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lista = findViewById(R.id.lista);

        pais.add("Guatemala");
        pais.add("USA");
        pais.add("Canada");
        pais.add("México");
        pais.add("Colombia");
        pais.add("Brasil");
        pais.add("Argentina");
        pais.add("Perú");
        pais.add("Francia");
        pais.add("Italia");

        img.add(R.drawable.ic_guatemala);
        img.add(R.drawable.ic_usa);
        img.add(R.drawable.ic_canada);
        img.add(R.drawable.ic_mexico);
        img.add(R.drawable.ic_colombia);
        img.add(R.drawable.ic_brasil);
        img.add(R.drawable.ic_argentina);
        img.add(R.drawable.ic_peru);
        img.add(R.drawable.ic_francia);
        img.add(R.drawable.ic_italia);

        info.add((long) 16600000);
        info.add((long) 328200000);
        info.add((long) 38005238);
        info.add((long) 128970000);
        info.add((long) 50374000);
        info.add((long) 210147000);
        info.add((long) 44939000);
        info.add((long) 33035304);
        info.add((long) 68011000);
        info.add((long) 59257566);

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, pais);
        lista.setAdapter(adapter);
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), MAPais.class);
                intent.putExtra("imagen", img.get(position));
                intent.putExtra("texto", info.get(position));

                startActivity(intent);
            }
        });

    }
}